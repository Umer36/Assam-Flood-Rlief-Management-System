
import axios from "axios"

axios

export const privateAxios = axios.create({

    baseURL : "http://localhost:8180/api/v1/rescue/request"
})

privateAxios.interceptors.request.use(config => {
    
})